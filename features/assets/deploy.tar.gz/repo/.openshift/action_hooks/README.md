For information about action hooks supported by OpenShift, consult the documentation:

https://github.com/openshift/origin-server/tree/master/node/README.writing_applications.md#action-hooks
